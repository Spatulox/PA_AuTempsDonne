class Admin extends User{

}