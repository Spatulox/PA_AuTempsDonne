<?php

class EtagereModel
{

}
?>