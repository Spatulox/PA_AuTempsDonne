package models

type Conversation struct {
	Ticket   Tickets
	Messages []Message
}
