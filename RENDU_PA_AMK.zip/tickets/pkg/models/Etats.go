package models

type Etats struct {
	Id  int64
	Nom string
}
