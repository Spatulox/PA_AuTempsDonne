package models

type Message struct {
	IdMessage   int64
	DateMessage string
	Text        string
	IdUser      int64
	Email       string
}
