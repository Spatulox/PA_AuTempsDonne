package models

type Categories struct {
	Id  int64
	Nom string
}
