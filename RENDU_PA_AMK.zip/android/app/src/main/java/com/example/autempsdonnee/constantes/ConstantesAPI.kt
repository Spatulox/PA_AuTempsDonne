import org.json.JSONObject
import java.io.File

class ConstantesAPI {

    object AppConstants {
        val API_BASE_URL = "http://192.168.56.1:8081/index.php"
    }

}