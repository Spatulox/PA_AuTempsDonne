const dico = {
    "EN":{

    },
    "FR":{

    }
}