<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="">

<link rel="stylesheet" type="text/css" href="../CSS/Balise.css">
<link rel="stylesheet" type="text/css" href="../CSS/Class.css">
<link rel="stylesheet" type="text/css" href="../CSS/Id.css">


<script type="text/javascript" src="../JS/functions.js"></script>
<script type="text/javascript" src="../JS/utils.js"></script>
<script type="text/javascript" src="../JS/user.js"></script>
<script type="text/javascript" src="../JS/popup.js"></script>


